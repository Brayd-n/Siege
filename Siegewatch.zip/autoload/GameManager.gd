extends Node
## Owns the high level run state: lives, wave counter, speed, game over.
## Scene-level managers register themselves here in Main._ready().

enum State { BUILD, WAVE, DRAFT, WON, LOST }

const START_LIVES := 20

var lives: int = START_LIVES
var state: int = State.BUILD
var wave: int = 0 ## number of the last wave that was started (0 = none yet)
var speed: float = 1.0
var paused: bool = false
var total_kills: int = 0

# Level being played (set from the main menu)
const BATTLE_SCENE := "res://scenes/main/Main.tscn"
const MENU_SCENE := "res://scenes/menu/MainMenu.tscn"
var level: Dictionary = LevelDefs.LEVELS[0]
var level_index: int = 0
var difficulty: String = "normal"
var mode: String = "campaign"      ## "campaign", "endless" or "challenge"
var seed_salt: int = 0

# Scene references (set by Main)
var main: Node3D = null
var map: Node3D = null
var camera: Camera3D = null
var enemy_manager: Node = null
var unit_manager: Node = null
var wave_manager: Node = null
var placement_manager: Node = null
var dialogue_manager: Node = null


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	EventBus.enemy_killed.connect(func(_e, _k): total_kills += 1)


func difficulty_def() -> Dictionary:
	return LevelDefs.DIFFICULTIES.get(difficulty, LevelDefs.DIFFICULTIES["normal"])


func reset_run() -> void:
	lives = int(difficulty_def()["lives"]) + Profile.start_lives_bonus()
	wave = 0
	total_kills = 0
	set_state(State.BUILD)
	set_speed(1.0)
	set_paused(false)
	EconomyManager.reset()
	BoonManager.reset()
	Profile.begin_run()


## Configure and load a battle.
func start_level(idx: int, diff: String, run_mode: String = "campaign") -> void:
	level_index = idx
	level = LevelDefs.get_level(idx)
	difficulty = diff
	mode = run_mode
	seed_salt = Profile.daily_challenge_salt() if run_mode == "challenge" else 0
	reset_run()
	get_tree().paused = false
	get_tree().change_scene_to_file(BATTLE_SCENE)


func restart_level() -> void:
	start_level(level_index, difficulty, mode)


func to_menu() -> void:
	set_speed(1.0)
	set_paused(false)
	main = null
	enemy_manager = null
	unit_manager = null
	wave_manager = null
	placement_manager = null
	dialogue_manager = null
	get_tree().change_scene_to_file(MENU_SCENE)


## Total waves in this run (0 = endless).
func total_waves() -> int:
	return WaveDefs.count()


func set_state(s: int) -> void:
	state = s
	EventBus.state_changed.emit(s)


func is_over() -> bool:
	return state == State.WON or state == State.LOST


func lose_lives(n: int) -> void:
	if is_over():
		return
	lives = max(0, lives - n)
	EventBus.lives_changed.emit(lives)
	EventBus.camera_shake.emit(0.25 + 0.05 * n)
	if lives <= 0:
		set_speed(1.0)
		set_state(State.LOST)
		EventBus.game_over.emit(false)


func add_lives(n: int) -> void:
	lives += n
	EventBus.lives_changed.emit(lives)


func win() -> void:
	if is_over():
		return
	set_speed(1.0)
	set_state(State.WON)
	EventBus.game_over.emit(true)


func set_speed(s: float) -> void:
	speed = s
	Engine.time_scale = s


func set_paused(p: bool) -> void:
	paused = p
	if is_inside_tree():
		get_tree().paused = p



## Drop static caches on quit so Godot doesn't report leaked resources.
func _exit_tree() -> void:
	ModelBuilder._mesh_cache.clear()
	UiTheme._fonts.clear()
	UiTheme._theme = null
	Projectile._scene = null
