extends Node
## Roguelike layer ("Spoils of War").
## After every wave the player drafts 1 of 3 random boons. Boons persist for the
## whole run and stack. Some are cursed Pacts with a real downside.
## Before some waves an Omen is rolled that changes only that wave.
##
## Stat queries: get_mult("damage", "archer") multiplies every matching mod key:
##   "damage:all" and "damage:archer".

const RARITY_COLORS := {
	"common": Color(0.78, 0.76, 0.7),
	"rare": Color(0.35, 0.62, 1.0),
	"legendary": Color(1.0, 0.72, 0.2),
	"cursed": Color(0.78, 0.3, 0.95),
}

const BOONS := [
	# ---------------- common (stackable stat boons)
	{"id": "sharpened_arrows", "name": "Sharpened Arrows", "rarity": "common", "stack": true,
		"desc": "Archers deal +20% damage.", "mods": {"damage:archer": 1.2}},
	{"id": "heavy_bolts", "name": "Heavier Bolts", "rarity": "common", "stack": true,
		"desc": "Crossbowmen deal +20% damage.", "mods": {"damage:crossbowman": 1.2}},
	{"id": "tempered_steel", "name": "Tempered Steel", "rarity": "common", "stack": true,
		"desc": "Knights deal +25% damage.", "mods": {"damage:knight": 1.25}},
	{"id": "pitch_oil", "name": "Barrels of Pitch", "rarity": "common", "stack": true,
		"desc": "Torch Throwers deal +20% damage and burns last 1s longer.",
		"mods": {"damage:torch_thrower": 1.2}, "add": {"burn_time": 1.0}},
	{"id": "eagle_eye", "name": "Eagle Eye", "rarity": "common", "stack": true,
		"desc": "All units gain +10% range.", "mods": {"range:all": 1.1}},
	{"id": "war_drums", "name": "War Drums", "rarity": "common", "stack": true,
		"desc": "All units attack 10% faster.", "mods": {"attack_speed:all": 1.1}},
	{"id": "tax_collectors", "name": "Tax Collectors", "rarity": "common", "stack": true,
		"desc": "+15% gold from kills.", "mods": {"gold_kill:all": 1.15}},
	{"id": "masonry", "name": "Stonemasons", "rarity": "common", "stack": true,
		"desc": "Repair the gate: +4 castle lives.", "instant": {"lives": 4}},
	{"id": "field_rations", "name": "Field Rations", "rarity": "common", "stack": true,
		"desc": "All units gain +25% max health.", "mods": {"max_hp:all": 1.25}},
	{"id": "quartermaster", "name": "Quartermaster", "rarity": "common", "stack": true,
		"desc": "Upgrades cost 12% less.", "mods": {"upgrade_cost:all": 0.88}},
	{"id": "war_chest", "name": "War Chest", "rarity": "common", "stack": true,
		"desc": "Gain 150 gold now.", "instant": {"gold": 150}},
	# ---------------- rare
	{"id": "royal_bounty", "name": "Royal Bounty", "rarity": "rare", "stack": true,
		"desc": "Gain 300 gold now.", "instant": {"gold": 300}},
	{"id": "battle_hymn", "name": "Battle Hymn", "rarity": "rare", "stack": true,
		"desc": "Special abilities recharge 30% faster.", "mods": {"special_cd:all": 0.7}},
	{"id": "fire_arrows", "name": "Fire Arrows", "rarity": "rare", "stack": false,
		"desc": "Archer arrows set enemies on fire.", "flags": ["fire_arrows"]},
	{"id": "barbed_bolts", "name": "Barbed Bolts", "rarity": "rare", "stack": false,
		"desc": "Crossbow bolts pierce 2 more enemies.", "add": {"pierce": 2}},
	{"id": "shield_brothers", "name": "Shield Brothers", "rarity": "rare", "stack": false,
		"desc": "Knights gain +15% damage for each other Knight within 7m (max 3).",
		"flags": ["shield_brothers"]},
	{"id": "recruiting_banner", "name": "Recruiting Banner", "rarity": "rare", "stack": true,
		"desc": "New soldiers cost 15% less.", "mods": {"unit_cost:all": 0.85}},
	{"id": "treasury_interest", "name": "Treasury Interest", "rarity": "rare", "stack": false,
		"desc": "At the end of each wave, earn 10% of your gold (max 150).",
		"flags": ["interest"]},
	{"id": "hawk_eyed", "name": "Hawk-Eyed Scouts", "rarity": "rare", "stack": false,
		"desc": "Units warn allies from 50% farther away and warnings last longer.",
		"flags": ["scouts"]},
	# ---------------- legendary
	{"id": "dragonsbane", "name": "Dragonsbane", "rarity": "legendary", "stack": false,
		"desc": "+50% damage against Trolls and Dragons.", "flags": ["dragonsbane"]},
	{"id": "kings_guard", "name": "King's Guard", "rarity": "legendary", "stack": false,
		"desc": "Archers covered by a Knight attack 35% faster (instead of 15%).",
		"flags": ["kings_guard"]},
	{"id": "inferno", "name": "Inferno", "rarity": "legendary", "stack": false,
		"desc": "Torch blasts are 40% larger and Fire Patches last twice as long.",
		"mods": {"radius:torch_thrower": 1.4}, "flags": ["inferno"]},
	{"id": "divine_favor", "name": "Divine Favor", "rarity": "legendary", "stack": false,
		"desc": "+8 castle lives now, and +1 life every wave you clear.",
		"instant": {"lives": 8}, "flags": ["divine_favor"]},
	# ---------------- cursed pacts (strong upside, real downside)
	{"id": "blood_pact", "name": "Blood Pact", "rarity": "cursed", "stack": false,
		"desc": "All units deal +35% damage. Lose 5 castle lives.",
		"mods": {"damage:all": 1.35}, "instant": {"lives": -5}},
	{"id": "mercenary_debt", "name": "Mercenary Debt", "rarity": "cursed", "stack": false,
		"desc": "Gain 450 gold now. Enemies have +15% health for the rest of the run.",
		"instant": {"gold": 450}, "mods": {"enemy_hp:all": 1.15}},
	{"id": "reckless_haste", "name": "Reckless Haste", "rarity": "cursed", "stack": false,
		"desc": "All units attack 25% faster, but take 60% more damage.",
		"mods": {"attack_speed:all": 1.25, "damage_taken:all": 1.6}},
]

const OMENS := [
	{"id": "swift", "name": "Omen: Swift Feet", "desc": "Enemies move 25% faster. Kills pay +30% gold.",
		"speed": 1.25, "gold": 1.3, "hp": 1.0, "count": 1.0},
	{"id": "ironhide", "name": "Omen: Ironhide", "desc": "Enemies have +30% health. Kills pay +35% gold.",
		"speed": 1.0, "gold": 1.35, "hp": 1.3, "count": 1.0},
	{"id": "horde", "name": "Omen: The Horde", "desc": "30% more enemies this wave. Wave bonus doubled.",
		"speed": 1.0, "gold": 1.0, "hp": 1.0, "count": 1.3, "bonus": 2.0},
	{"id": "blood_moon", "name": "Omen: Blood Moon", "desc": "Enemies have +15% health and speed. Kills pay +50% gold.",
		"speed": 1.15, "gold": 1.5, "hp": 1.15, "count": 1.0},
]

var active: Array = []          ## picked boon dictionaries (duplicates allowed for stackables)
var current_omen: Dictionary = {}
var current_options: Array = []
var rerolls: int = 0
var free_rerolls_left: int = 0
var rng := RandomNumberGenerator.new()


func _ready() -> void:
	rng.randomize()


func reset() -> void:
	active.clear()
	current_omen = {}
	current_options.clear()
	rerolls = 0
	free_rerolls_left = Profile.free_rerolls()
	EventBus.omen_changed.emit(current_omen)


# ------------------------------------------------------------------ queries
func get_mult(stat: String, unit_type: String = "all") -> float:
	var m := Profile.armory_mult(stat, unit_type)
	var k_all := stat + ":all"
	var k_type := stat + ":" + unit_type
	for b in active:
		var mods: Dictionary = b.get("mods", {})
		if mods.has(k_all):
			m *= float(mods[k_all])
		if unit_type != "all" and mods.has(k_type):
			m *= float(mods[k_type])
	return m


func get_add(stat: String) -> float:
	var v := 0.0
	for b in active:
		var adds: Dictionary = b.get("add", {})
		if adds.has(stat):
			v += float(adds[stat])
	return v


func has_flag(flag: String) -> bool:
	for b in active:
		if flag in b.get("flags", []):
			return true
	return false


func owns(id: String) -> bool:
	for b in active:
		if b["id"] == id:
			return true
	return false


func count_owned(id: String) -> int:
	var c := 0
	for b in active:
		if b["id"] == id:
			c += 1
	return c


func omen_value(key: String, default_value: float = 1.0) -> float:
	if current_omen.is_empty():
		return default_value
	return float(current_omen.get(key, default_value))


## Global multiplier applied to enemy max HP (curses + omen).
func enemy_hp_mult() -> float:
	return get_mult("enemy_hp") * omen_value("hp") * float(GameManager.difficulty_def()["hp"])


# ------------------------------------------------------------------ drafting
func reroll_cost() -> int:
	if free_rerolls_left > 0:
		return 0
	return 40 + rerolls * 25


func roll_options(wave_number: int) -> Array:
	var weights := {
		"common": 60.0,
		"rare": 22.0 + wave_number * 2.0,
		"legendary": 4.0 + wave_number * 1.5,
		"cursed": 8.0 if wave_number >= 2 else 0.0,
	}
	var pool: Array = []
	for b in BOONS:
		if not b.get("stack", false) and owns(b["id"]):
			continue
		pool.append(b)
	var picks: Array = []
	var guard := 0
	while picks.size() < 3 and guard < 200 and pool.size() > 0:
		guard += 1
		var rarity := _roll_rarity(weights)
		var candidates := pool.filter(func(b): return b["rarity"] == rarity and not picks.has(b))
		if candidates.is_empty():
			continue
		picks.append(candidates[rng.randi() % candidates.size()])
	return picks


func _roll_rarity(weights: Dictionary) -> String:
	var total := 0.0
	for k in weights:
		total += weights[k]
	var r := rng.randf() * total
	for k in weights:
		r -= weights[k]
		if r <= 0.0:
			return k
	return "common"


func open_draft(wave_number: int) -> void:
	current_options = roll_options(wave_number)
	EventBus.boon_draft_opened.emit(current_options)


func reroll(wave_number: int) -> bool:
	var cost := reroll_cost()
	if cost == 0:
		free_rerolls_left -= 1
	elif not EconomyManager.spend(cost):
		return false
	else:
		rerolls += 1
	open_draft(wave_number)
	return true


func pick(boon: Dictionary) -> void:
	active.append(boon)
	var inst: Dictionary = boon.get("instant", {})
	if inst.has("gold"):
		EconomyManager.add(int(inst["gold"]))
	if inst.has("lives"):
		var l := int(inst["lives"])
		if l >= 0:
			GameManager.add_lives(l)
		else:
			GameManager.lose_lives(-l)
	current_options.clear()
	EventBus.boon_picked.emit(boon)
	EventBus.feed_message.emit("Spoils of War", "%s - %s" % [boon["name"], boon["desc"]],
		RARITY_COLORS.get(boon["rarity"], Color.WHITE))


## Called after the draft to decide whether the next wave carries an omen.
func roll_omen(next_wave: int) -> void:
	current_omen = {}
	var chance := 1.0 if GameManager.mode == "challenge" else 0.45
	if next_wave >= 3 and not WaveDefs.is_boss_wave(next_wave) and rng.randf() < chance:
		current_omen = OMENS[rng.randi() % OMENS.size()]
	EventBus.omen_changed.emit(current_omen)


func clear_omen() -> void:
	current_omen = {}
	EventBus.omen_changed.emit(current_omen)
