class_name EnemyDefs
extends RefCounted
## Static balance data for enemies.
## resist maps Damage.Type -> damage multiplier (lower = more resistant).

const DATA := {
	"goblin": {
		"name": "Goblin", "hp": 45.0, "speed": 3.2, "reward": 10, "lives": 1, "armor": 0.0,
		"heavy": false, "contact": 4.0, "contact_range": 1.9, "resist": {},
	},
	"goblin_archer": {
		"name": "Goblin Archer", "hp": 85.0, "speed": 2.6, "reward": 14, "lives": 1, "armor": 0.0,
		"heavy": false, "contact": 3.0, "contact_range": 1.9, "resist": {},
	},
	"wolf_rider": {
		"name": "Wolf Rider", "hp": 85.0, "speed": 5.4, "reward": 15, "lives": 1, "armor": 0.0,
		"heavy": false, "contact": 6.0, "contact_range": 2.1, "resist": {},
	},
	"shaman": {
		"name": "Goblin Shaman", "hp": 120.0, "speed": 2.4, "reward": 18, "lives": 1, "armor": 0.0,
		"heavy": false, "contact": 3.0, "contact_range": 1.9, "resist": {Damage.Type.ARCANE: 0.7},
	},
	"orc": {
		"name": "Orc", "hp": 240.0, "speed": 2.2, "reward": 25, "lives": 2, "armor": 0.3,
		"heavy": true, "contact": 12.0, "contact_range": 2.2, "resist": {},
	},
	"troll": {
		"name": "Troll", "hp": 1000.0, "speed": 1.8, "reward": 75, "lives": 3, "armor": 0.1,
		"heavy": true, "contact": 28.0, "contact_range": 2.9,
		"resist": {Damage.Type.NORMAL: 0.5, Damage.Type.PIERCING: 1.0, Damage.Type.FIRE: 1.5},
	},
	"dragon": {
		"name": "Dragon", "hp": 16000.0, "speed": 1.55, "reward": 500, "lives": 10, "armor": 0.15,
		"heavy": true, "contact": 0.0, "contact_range": 0.0,
		"resist": {Damage.Type.NORMAL: 0.85, Damage.Type.FIRE: 0.5},
	},
}


static func get_def(type: String) -> Dictionary:
	return DATA.get(type, {})
