extends Node
## Spawns enemies at the portal and keeps the list of living enemies that
## soldiers query for targeting.

const SCENES := {
	"goblin": preload("res://scenes/enemies/Goblin.tscn"),
	"goblin_archer": preload("res://scenes/enemies/GoblinArcher.tscn"),
	"orc": preload("res://scenes/enemies/Orc.tscn"),
	"troll": preload("res://scenes/enemies/Troll.tscn"),
	"wolf_rider": preload("res://scenes/enemies/WolfRider.tscn"),
	"dragon": preload("res://scenes/enemies/Dragon.tscn"),
	"shaman": preload("res://scenes/enemies/Shaman.tscn"),
}

var enemies: Array[Enemy] = []

@onready var container: Node3D = get_node("../../Enemies")


func _ready() -> void:
	EventBus.enemy_killed.connect(_on_enemy_gone.unbind(1))
	EventBus.enemy_reached_castle.connect(_on_enemy_gone)


func spawn(type: String, hp_mult: float = 1.0, speed_mult: float = 1.0) -> Enemy:
	var scene: PackedScene = SCENES.get(type)
	if scene == null:
		push_warning("Unknown enemy type " + type)
		return null
	var e: Enemy = scene.instantiate()
	container.add_child(e)
	e.setup(GameManager.map, hp_mult * BoonManager.enemy_hp_mult(), speed_mult * BoonManager.omen_value("speed"))
	enemies.append(e)
	EventBus.enemy_spawned.emit(e)
	return e


func _on_enemy_gone(e) -> void:
	enemies.erase(e)


func alive_count() -> int:
	return enemies.size()


func has_type_alive(type: String) -> bool:
	for e in enemies:
		if is_instance_valid(e) and e.alive and e.enemy_type == type:
			return true
	return false


## Enemies within a horizontal radius.
func enemies_near(pos: Vector3, radius: float, include_flying: bool = true) -> Array:
	var out: Array = []
	for e in enemies:
		if not is_instance_valid(e) or not e.alive:
			continue
		if e.flying and not include_flying:
			continue
		if Vector2(e.global_position.x - pos.x, e.global_position.z - pos.z).length() <= radius:
			out.append(e)
	return out


## Remove every enemy without rewards (debug / restart).
func clear_all() -> void:
	for e in enemies:
		if is_instance_valid(e):
			e.alive = false
			e.queue_free()
	enemies.clear()
