class_name Enemy
extends Node3D
## Base enemy: follows the road by distance ("progress"), takes typed damage,
## suffers status effects, attacks soldiers it walks past, pays gold on death
## and costs castle lives if it reaches the gate.

@export var enemy_type: String = "goblin"

var def: Dictionary = {}
var display_name: String = ""
var max_hp: float = 50.0
var hp: float = 50.0
var speed: float = 3.0
var reward: int = 10
var lives_cost: int = 1
var armor: float = 0.0
var resist: Dictionary = {}
var is_heavy: bool = false
var is_boss: bool = false
var flying: bool = false
var fly_height: float = 0.0
var contact_damage: float = 0.0
var contact_range: float = 2.0

var progress: float = 0.0     ## distance travelled along the road
var lateral: float = 0.0      ## sideways offset from the road centre
var alive: bool = true
var burn_time: float = 0.0
var burn_dps: float = 0.0
var burn_source: Node = null
var slow_time: float = 0.0
var slow_mult: float = 1.0
var contact_timer: float = 0.0
var anim_t: float = 0.0
var attack_anim: float = 0.0
var hit_pop: float = 0.0
var model_scale: float = 1.0
var height: float = 1.8       ## used for health bar & hit point placement

var map: GameMap
var rig: Dictionary = {}
var hp_bar: MeshInstance3D
var burn_fx: GPUParticles3D

@onready var model_root: Node3D = $Model


const BASE_SCALE := 1.35


func _ready() -> void:
	add_to_group("enemies")
	model_scale *= BASE_SCALE
	def = EnemyDefs.get_def(enemy_type)
	display_name = def.get("name", enemy_type)
	rig = ModelBuilder.build_enemy(enemy_type)
	model_root.add_child(rig["root"])
	model_root.scale = Vector3.ONE * model_scale
	_build_health_bar()
	anim_t = randf() * 10.0


## Called by EnemyManager right after instancing.
func setup(game_map: GameMap, hp_mult: float, speed_mult: float) -> void:
	map = game_map
	if def.is_empty():
		def = EnemyDefs.get_def(enemy_type)
	max_hp = float(def.get("hp", 50.0)) * hp_mult
	hp = max_hp
	speed = float(def.get("speed", 3.0)) * speed_mult * randf_range(0.95, 1.05)
	reward = int(def.get("reward", 10))
	lives_cost = int(def.get("lives", 1))
	armor = float(def.get("armor", 0.0))
	resist = def.get("resist", {})
	is_heavy = bool(def.get("heavy", false))
	contact_damage = float(def.get("contact", 0.0))
	contact_range = float(def.get("contact_range", 2.0))
	if not flying:
		lateral = randf_range(-0.7, 0.7)
	global_position = map.sample_path(0.0)


func _build_health_bar() -> void:
	hp_bar = MeshInstance3D.new()
	var q := QuadMesh.new()
	q.size = Vector2(1.1, 0.13) * (1.6 if is_boss else 1.0)
	hp_bar.mesh = q
	var m := ShaderMaterial.new()
	m.shader = Mats.shader("res://assets/shaders/healthbar.gdshader")
	hp_bar.material_override = m
	hp_bar.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	hp_bar.position = Vector3(0, height * model_scale + 0.35, 0)
	hp_bar.visible = false
	add_child(hp_bar)


func _process(delta: float) -> void:
	if not alive or map == null:
		return
	_update_status(delta)
	if not alive:
		return
	var move := speed * delta
	if slow_time > 0.0:
		move *= slow_mult
	progress += move
	if progress >= map.path_length:
		_reach_castle()
		return
	var p := map.sample_path(progress)
	var dir := map.path_direction(progress)
	var side := Vector3(-dir.z, 0, dir.x)
	global_position = p + side * lateral + Vector3.UP * fly_height
	var target_yaw := atan2(dir.x, dir.z)
	rotation.y = lerp_angle(rotation.y, target_yaw, clamp(delta * 8.0, 0.0, 1.0))
	anim_t += delta * speed
	attack_anim = max(0.0, attack_anim - delta * 3.0)
	hit_pop = max(0.0, hit_pop - delta * 6.0)
	model_root.scale = Vector3.ONE * model_scale * (1.0 + hit_pop * 0.12)
	_animate(delta)
	_special_process(delta)
	if contact_damage > 0.0:
		_contact_attack(delta)


## Walk cycle for humanoids; subclasses override for special rigs.
func _animate(_delta: float) -> void:
	var s := sin(anim_t * 2.6)
	if rig.has("leg_l"):
		(rig["leg_l"] as Node3D).rotation.x = s * 0.6
		(rig["leg_r"] as Node3D).rotation.x = -s * 0.6
	if rig.has("arm_l"):
		(rig["arm_l"] as Node3D).rotation.x = -s * 0.4
	if rig.has("arm_r"):
		(rig["arm_r"] as Node3D).rotation.x = s * 0.35 - attack_anim * 1.8
	if rig.has("body"):
		(rig["body"] as Node3D).position.y = abs(sin(anim_t * 2.6)) * 0.08


func _special_process(_delta: float) -> void:
	pass


func _contact_attack(delta: float) -> void:
	contact_timer -= delta
	if contact_timer > 0.0:
		return
	var um := GameManager.unit_manager
	if um == null:
		return
	var target: FriendlyUnit = um.nearest_unit(global_position, contact_range, "", true)
	if target:
		contact_timer = 1.3
		attack_anim = 1.0
		target.take_damage(contact_damage, self)
	else:
		contact_timer = 0.2


func _update_status(delta: float) -> void:
	if burn_time > 0.0:
		burn_time -= delta
		var src: Node = burn_source if is_instance_valid(burn_source) else null
		_apply_damage(burn_dps * delta * _resist_mult(Damage.Type.FIRE), src, false)
		if burn_fx == null:
			burn_fx = FX.fire_emitter(0.9 * model_scale)
			burn_fx.position = Vector3(0, height * model_scale * 0.5, 0)
			add_child(burn_fx)
		burn_fx.emitting = true
	elif burn_fx and burn_fx.emitting:
		burn_fx.emitting = false
	if slow_time > 0.0:
		slow_time -= delta


func is_burning() -> bool:
	return burn_time > 0.0


func apply_burn(dps: float, duration: float, source: Node = null) -> void:
	if source:
		burn_source = source
	burn_dps = max(burn_dps if burn_time > 0.0 else 0.0, dps)
	burn_time = max(burn_time, duration)


func apply_slow(mult: float, duration: float) -> void:
	slow_mult = min(slow_mult if slow_time > 0.0 else 1.0, mult)
	slow_time = max(slow_time, duration)


func _resist_mult(dtype: int) -> float:
	return float(resist.get(dtype, 1.0))


## Main damage entry point. Returns damage actually dealt.
func take_damage(amount: float, dtype: int, source: Node = null) -> float:
	if not alive:
		return 0.0
	var arm := armor
	if dtype == Damage.Type.PIERCING:
		arm *= 0.25
	elif dtype == Damage.Type.FIRE:
		arm *= 0.5
	elif dtype == Damage.Type.ARCANE:
		arm = 0.0
	var dmg := amount * _resist_mult(dtype) * (1.0 - arm)
	if BoonManager.has_flag("dragonsbane") and (enemy_type == "troll" or enemy_type == "dragon"):
		dmg *= 1.5
	_apply_damage(dmg, source, true)
	return dmg


func _apply_damage(dmg: float, source: Node, pop: bool) -> void:
	if not alive:
		return
	hp -= dmg
	if pop:
		hit_pop = 1.0
	hp_bar.visible = hp < max_hp
	var f: float = clamp(hp / max_hp, 0.0, 1.0)
	hp_bar.set_instance_shader_parameter("fill", f)
	hp_bar.set_instance_shader_parameter("bar_color", Color(0.9, 0.25, 0.2).lerp(Color(0.35, 0.85, 0.3), f))
	if hp <= 0.0:
		die(source)


func die(killer: Node) -> void:
	if not alive:
		return
	alive = false
	var paid := EconomyManager.reward_kill(reward)
	FX.float_text(global_position + Vector3.UP * (height * model_scale + 0.3), "+%d" % paid, Color(1.0, 0.84, 0.3), 44 if not is_boss else 90)
	FX.death_puff(global_position, model_scale)
	Sfx.play("death", -6.0, 0.15, 0.04)
	Sfx.play("coin", -10.0, 0.1, 0.08)
	EventBus.enemy_killed.emit(self, killer)
	hp_bar.visible = false
	if burn_fx:
		burn_fx.emitting = false
	var tw := create_tween()
	tw.set_parallel(true)
	tw.tween_property(model_root, "rotation:x", -PI * 0.5, 0.35)
	tw.tween_property(model_root, "position:y", -0.4 * model_scale, 0.6).set_delay(0.3)
	tw.tween_property(model_root, "scale", Vector3.ONE * model_scale * 0.6, 0.6).set_delay(0.3)
	tw.chain().tween_callback(queue_free)


func _reach_castle() -> void:
	alive = false
	GameManager.lose_lives(lives_cost)
	Sfx.play("bell", -4.0, 0.05, 0.2)
	EventBus.enemy_reached_castle.emit(self)
	EventBus.feed_message.emit("Castle Gate", "A %s broke through! -%d %s" % [display_name, lives_cost, "life" if lives_cost == 1 else "lives"], UiTheme.RED)
	queue_free()


## World point projectiles aim at.
func aim_point() -> Vector3:
	return global_position + Vector3.UP * height * model_scale * 0.55


## 0..1 fraction of road travelled.
func path_fraction() -> float:
	if map == null:
		return 0.0
	return progress / map.path_length
