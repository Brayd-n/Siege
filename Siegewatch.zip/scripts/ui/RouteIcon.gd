class_name RouteIcon
extends Control
## Mini-map of a level's road drawn on parchment for the level-select cards.

var path: Array = []
var tint: Color = Color(0.55, 0.62, 0.3)
var locked := false


func _init(p: Array = [], t: Color = Color.WHITE, is_locked: bool = false) -> void:
	path = p
	tint = t
	locked = is_locked
	custom_minimum_size = Vector2(236, 118)
	mouse_filter = Control.MOUSE_FILTER_IGNORE


func _to_px(v: Vector2) -> Vector2:
	# world x -60..60, z -30..30  ->  icon rect with margin
	var m := 8.0
	var w := size.x - m * 2
	var h := size.y - m * 2
	return Vector2(m + (v.x + 60.0) / 120.0 * w, m + (v.y + 30.0) / 60.0 * h)


func _draw() -> void:
	var r := Rect2(Vector2.ZERO, size)
	draw_rect(r, tint.darkened(0.55) if not locked else Color(0.15, 0.14, 0.13))
	draw_rect(r.grow(-3), tint.darkened(0.25) if not locked else Color(0.2, 0.19, 0.18))
	if path.size() < 2:
		return
	var pts := PackedVector2Array()
	for p in path:
		pts.append(_to_px(p))
	var road := Color(0.55, 0.42, 0.28) if not locked else Color(0.35, 0.33, 0.3)
	draw_polyline(pts, Color(0, 0, 0, 0.35), 7.0, true)
	draw_polyline(pts, road, 5.0, true)
	# portal and castle
	draw_circle(pts[0], 6.0, Color(0.55, 0.25, 0.85) if not locked else Color(0.3, 0.3, 0.3))
	var c := pts[pts.size() - 1]
	draw_rect(Rect2(c + Vector2(-2, -9), Vector2(14, 18)), Color(0.62, 0.6, 0.58) if not locked else Color(0.3, 0.3, 0.3))
	draw_rect(Rect2(c + Vector2(-2, -12), Vector2(4, 4)), Color(0.62, 0.6, 0.58) if not locked else Color(0.3, 0.3, 0.3))
	draw_rect(Rect2(c + Vector2(8, -12), Vector2(4, 4)), Color(0.62, 0.6, 0.58) if not locked else Color(0.3, 0.3, 0.3))
