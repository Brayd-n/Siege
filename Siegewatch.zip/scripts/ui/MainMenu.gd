extends Node3D
## Main menu / campaign map. A live 3D battlefield slowly orbits behind the UI.
## Shows the player profile (rank, XP, Crowns), live events, daily login reward,
## daily quests, the daily challenge, the campaign level select with medals and
## unlocks, and the Armory, Achievements and Settings screens.

var cam: Camera3D
var orbit_t: float = 0.0
var ui: Control
var lbl_crowns: Label
var lbl_rank: Label
var xp_bar: ProgressBar
var quests_box: VBoxContainer
var levels_grid: GridContainer
var overlay: Control
var overlay_box: VBoxContainer
var loading: Control


func _ready() -> void:
	get_tree().paused = false
	Engine.time_scale = 1.0
	GameManager.main = null
	# backdrop: the most recently unlocked map
	var backdrop := 0
	for i in LevelDefs.count():
		if Profile.level_unlocked(i):
			backdrop = i
	GameManager.level = LevelDefs.get_level(backdrop)
	GameManager.level_index = backdrop
	var map: Node3D = load("res://scenes/map/Map.tscn").instantiate()
	add_child(map)
	GameManager.map = map
	Atmosphere.build(self, LevelDefs.theme(GameManager.level))
	cam = Camera3D.new()
	cam.fov = 45.0
	cam.far = 600.0
	add_child(cam)
	cam.current = true
	Sfx.start_ambience()
	_build_ui()
	Profile.crowns_changed.connect(_on_crowns_changed)
	Profile.profile_changed.connect(_refresh_profile)
	_refresh_profile()
	if not Profile.data.get("seen_intro", false):
		call_deferred("_show_intro")
	elif Profile.login_pending():
		call_deferred("_show_login")


func _process(delta: float) -> void:
	orbit_t += delta * 0.03
	var r := 78.0
	cam.position = Vector3(cos(orbit_t) * r, 42.0, sin(orbit_t) * r * 0.75)
	cam.look_at(Vector3(0, 0, 0), Vector3.UP)


# ================================================================== layout
func _panel(bg: Color = UiTheme.PANEL_BG, border: Color = UiTheme.GOLD_DIM) -> PanelContainer:
	var p := PanelContainer.new()
	p.add_theme_stylebox_override("panel", UiTheme.panel_style(bg, border))
	return p


func _button(text: String, cb: Callable, min_w: float = 0.0, size: int = 18) -> Button:
	var b := Button.new()
	b.text = text
	b.focus_mode = Control.FOCUS_NONE
	b.custom_minimum_size.x = min_w
	b.add_theme_font_size_override("font_size", size)
	b.pressed.connect(cb)
	b.pressed.connect(_click)
	return b


func _click() -> void:
	Sfx.play("click", -8.0)


func _build_ui() -> void:
	var layer := CanvasLayer.new()
	layer.layer = 5
	add_child(layer)
	ui = Control.new()
	ui.set_anchors_preset(Control.PRESET_FULL_RECT)
	ui.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ui.theme = UiTheme.get_theme()
	layer.add_child(ui)
	var shade := ColorRect.new()
	shade.color = Color(0.02, 0.015, 0.01, 0.35)
	shade.set_anchors_preset(Control.PRESET_FULL_RECT)
	shade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ui.add_child(shade)
	var margin := MarginContainer.new()
	margin.set_anchors_preset(Control.PRESET_FULL_RECT)
	for side in ["left", "right", "top", "bottom"]:
		margin.add_theme_constant_override("margin_" + side, 22)
	margin.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ui.add_child(margin)
	var cols := HBoxContainer.new()
	cols.add_theme_constant_override("separation", 20)
	cols.mouse_filter = Control.MOUSE_FILTER_IGNORE
	margin.add_child(cols)
	cols.add_child(_left_column())
	cols.add_child(_center_column())
	cols.add_child(_right_column())
	overlay = Control.new()
	overlay.set_anchors_preset(Control.PRESET_FULL_RECT)
	overlay.mouse_filter = Control.MOUSE_FILTER_STOP
	overlay.visible = false
	ui.add_child(overlay)
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.65)
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	overlay.add_child(dim)
	var center := CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	overlay.add_child(center)
	var op := _panel(Color(0.08, 0.065, 0.05, 0.98), UiTheme.GOLD)
	center.add_child(op)
	var sc := ScrollContainer.new()
	sc.custom_minimum_size = Vector2(760, 0)
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	op.add_child(sc)
	overlay_box = VBoxContainer.new()
	overlay_box.add_theme_constant_override("separation", 10)
	overlay_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sc.add_child(overlay_box)
	loading = Control.new()
	loading.set_anchors_preset(Control.PRESET_FULL_RECT)
	loading.mouse_filter = Control.MOUSE_FILTER_STOP
	loading.visible = false
	ui.add_child(loading)
	var lb := ColorRect.new()
	lb.color = Color(0.03, 0.02, 0.02, 0.92)
	lb.set_anchors_preset(Control.PRESET_FULL_RECT)
	loading.add_child(lb)
	var lc := CenterContainer.new()
	lc.set_anchors_preset(Control.PRESET_FULL_RECT)
	loading.add_child(lc)
	lc.add_child(UiTheme.label("Preparing the battlefield...", 40, UiTheme.GOLD, UiTheme.font_title()))


func _left_column() -> Control:
	var vb := VBoxContainer.new()
	vb.custom_minimum_size.x = 360
	vb.add_theme_constant_override("separation", 12)
	var logo := UiTheme.label("SIEGEWATCH", 62, UiTheme.GOLD, UiTheme.font_title())
	logo.add_theme_constant_override("outline_size", 12)
	vb.add_child(logo)
	vb.add_child(UiTheme.label("The Kingdom's Last Watch", 22, UiTheme.PARCHMENT, UiTheme.font_italic()))
	# profile
	var pp := _panel()
	vb.add_child(pp)
	var pv := VBoxContainer.new()
	pp.add_child(pv)
	lbl_rank = UiTheme.label("Commander Rank 1", 22, UiTheme.PARCHMENT, UiTheme.font_title())
	pv.add_child(lbl_rank)
	xp_bar = ProgressBar.new()
	xp_bar.custom_minimum_size = Vector2(0, 14)
	xp_bar.show_percentage = false
	pv.add_child(xp_bar)
	var ch := HBoxContainer.new()
	ch.add_child(HudIcon.new("star", UiTheme.GOLD, 28))
	lbl_crowns = UiTheme.label("0 Crowns", 24, UiTheme.GOLD, UiTheme.font_title())
	ch.add_child(lbl_crowns)
	pv.add_child(ch)
	var streak := UiTheme.label("", 15, Color(0.75, 0.7, 0.62), UiTheme.font_italic())
	streak.name = "Streak"
	pv.add_child(streak)
	# live events
	var events := Profile.active_events()
	if not events.is_empty():
		var ep := _panel(Color(0.12, 0.06, 0.1, 0.9), Color(0.85, 0.55, 1.0))
		vb.add_child(ep)
		var ev := VBoxContainer.new()
		ep.add_child(ev)
		ev.add_child(UiTheme.label("LIVE EVENTS", 15, Color(0.85, 0.55, 1.0), UiTheme.font_title()))
		for e in events:
			var el := UiTheme.label("%s - %s" % [e["name"], e["desc"]], 15, UiTheme.PARCHMENT)
			el.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
			el.custom_minimum_size.x = 330
			ev.add_child(el)
	# menu buttons
	for entry in [["ARMORY", _show_armory], ["ACHIEVEMENTS", _show_achievements], ["SETTINGS", _show_settings], ["QUIT", _quit]]:
		var b := _button(entry[0], entry[1], 0, 20)
		b.custom_minimum_size.y = 46
		b.add_theme_font_override("font", UiTheme.font_title())
		vb.add_child(b)
	return vb


func _center_column() -> Control:
	var vb := VBoxContainer.new()
	vb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	vb.add_theme_constant_override("separation", 10)
	var t := UiTheme.label("CAMPAIGN", 34, UiTheme.GOLD, UiTheme.font_title())
	t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	t.add_theme_constant_override("outline_size", 8)
	vb.add_child(t)
	var cc := CenterContainer.new()
	vb.add_child(cc)
	levels_grid = GridContainer.new()
	levels_grid.columns = 3
	levels_grid.add_theme_constant_override("h_separation", 12)
	levels_grid.add_theme_constant_override("v_separation", 12)
	cc.add_child(levels_grid)
	_build_level_cards()
	return vb


func _right_column() -> Control:
	var vb := VBoxContainer.new()
	vb.custom_minimum_size.x = 340
	vb.add_theme_constant_override("separation", 12)
	# daily challenge
	var dp := _panel(Color(0.1, 0.07, 0.04, 0.92), UiTheme.GOLD)
	vb.add_child(dp)
	var dv := VBoxContainer.new()
	dp.add_child(dv)
	dv.add_child(UiTheme.label("DAILY CHALLENGE", 18, UiTheme.GOLD, UiTheme.font_title()))
	var idx := Profile.daily_challenge_level()
	var lv := LevelDefs.get_level(idx)
	var dl := UiTheme.label("%s on Hard. An omen hangs over every wave.\nFirst win today: +100 Crowns." % lv["name"], 15, UiTheme.PARCHMENT)
	dl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	dl.custom_minimum_size.x = 310
	dv.add_child(dl)
	var done: bool = Profile.data["daily"].get("challenge_done", false)
	var db := _button("COMPLETED TODAY" if done else "PLAY CHALLENGE", _play.bind(idx, "hard", "challenge"))
	db.add_theme_font_override("font", UiTheme.font_title())
	dv.add_child(db)
	# quests
	var qp := _panel()
	vb.add_child(qp)
	var qv := VBoxContainer.new()
	qp.add_child(qv)
	qv.add_child(UiTheme.label("DAILY QUESTS", 18, UiTheme.GOLD, UiTheme.font_title()))
	qv.add_child(UiTheme.label("New quests every day.", 13, Color(0.7, 0.65, 0.58), UiTheme.font_italic()))
	quests_box = VBoxContainer.new()
	quests_box.add_theme_constant_override("separation", 8)
	qv.add_child(quests_box)
	return vb


func _build_level_cards() -> void:
	for c in levels_grid.get_children():
		c.queue_free()
	for i in LevelDefs.count():
		var lv := LevelDefs.get_level(i)
		var unlocked := Profile.level_unlocked(i)
		var th := LevelDefs.theme(lv)
		var card := Button.new()
		card.focus_mode = Control.FOCUS_NONE
		card.custom_minimum_size = Vector2(252, 232)
		card.disabled = not unlocked
		card.pressed.connect(_choose_difficulty.bind(i))
		card.pressed.connect(_click)
		levels_grid.add_child(card)
		var v := VBoxContainer.new()
		v.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT, Control.PRESET_MODE_MINSIZE, 8)
		v.mouse_filter = Control.MOUSE_FILTER_IGNORE
		v.add_theme_constant_override("separation", 3)
		card.add_child(v)
		v.add_child(RouteIcon.new(lv["path"], th.get("icon", Color(0.4, 0.55, 0.3)), not unlocked))
		var nl := UiTheme.label("%d. %s" % [i + 1, lv["name"]], 17, UiTheme.PARCHMENT if unlocked else Color(0.5, 0.48, 0.45), UiTheme.font_title())
		v.add_child(nl)
		var info := ""
		if unlocked:
			info = "%d waves" % int(lv["waves"])
			var u: String = lv.get("unlock", "")
			if u != "" and not Profile.is_unit_unlocked(u):
				info += "  |  Unlocks " + UnitDefs.get_def(u)["name"]
			var best := Profile.endless_best(lv["id"])
			if best > 0:
				info += "  |  Endless best %d" % best
		else:
			info = "Locked - beat level %d" % i
		var il := UiTheme.label(info, 13, Color(0.75, 0.7, 0.62))
		il.clip_text = true
		il.custom_minimum_size.x = 236
		v.add_child(il)
		var medals := HBoxContainer.new()
		medals.add_theme_constant_override("separation", 6)
		v.add_child(medals)
		var got := Profile.medals(lv["id"])
		for d in LevelDefs.DIFFICULTY_ORDER:
			var dd: Dictionary = LevelDefs.DIFFICULTIES[d]
			var col: Color = dd["color"] if d in got else Color(0.25, 0.23, 0.2)
			var m := HudIcon.new("star", col, 18)
			m.tooltip_text = dd["name"]
			medals.add_child(m)
			medals.add_child(UiTheme.label(dd["name"], 12, col))


func _refresh_profile() -> void:
	if lbl_crowns == null:
		return
	lbl_crowns.text = "%d Crowns" % Profile.crowns()
	lbl_rank.text = "Commander Rank %d" % Profile.player_level()
	xp_bar.max_value = Profile.xp_to_next()
	xp_bar.value = Profile.xp()
	xp_bar.tooltip_text = "%d / %d XP" % [Profile.xp(), Profile.xp_to_next()]
	var streak := lbl_rank.get_parent().get_node_or_null("Streak") as Label
	if streak:
		streak.text = "Login streak: %d day%s" % [Profile.login_streak(), "" if Profile.login_streak() == 1 else "s"]
	_refresh_quests()


func _on_crowns_changed(_c: int) -> void:
	_refresh_profile()


func _refresh_quests() -> void:
	if quests_box == null:
		return
	var quests := Profile.daily_quests()   # may roll new quests (emits profile_changed) - do it first
	for c in quests_box.get_children():
		quests_box.remove_child(c)
		c.queue_free()
	for i in quests.size():
		var q: Dictionary = quests[i]
		var row := VBoxContainer.new()
		quests_box.add_child(row)
		var top := HBoxContainer.new()
		row.add_child(top)
		var ql := UiTheme.label(q["text"], 15, UiTheme.PARCHMENT if not q["claimed"] else Color(0.5, 0.48, 0.45))
		ql.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		top.add_child(ql)
		top.add_child(UiTheme.label("+%d" % int(q["reward"]), 15, UiTheme.GOLD, UiTheme.font_bold()))
		var bar := ProgressBar.new()
		bar.max_value = int(q["target"])
		bar.value = int(q["progress"])
		bar.show_percentage = false
		bar.custom_minimum_size = Vector2(0, 10)
		row.add_child(bar)
		if q["claimed"]:
			row.add_child(UiTheme.label("Claimed", 13, Color(0.5, 0.48, 0.45), UiTheme.font_italic()))
		elif int(q["progress"]) >= int(q["target"]):
			var cb := _button("CLAIM REWARD", _claim.bind(i), 0, 15)
			cb.add_theme_color_override("font_color", UiTheme.GREEN)
			row.add_child(cb)
		else:
			row.add_child(UiTheme.label("%d / %d" % [int(q["progress"]), int(q["target"])], 13, Color(0.7, 0.65, 0.58)))


func _claim(i: int) -> void:
	Profile.claim_quest(i)
	_refresh_quests()


# ================================================================== overlays
func _open_overlay(title: String) -> void:
	for c in overlay_box.get_children():
		c.queue_free()
	var t := UiTheme.label(title, 36, UiTheme.GOLD, UiTheme.font_title())
	t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	overlay_box.add_child(t)
	overlay.visible = true
	overlay.modulate.a = 0.0
	create_tween().tween_property(overlay, "modulate:a", 1.0, 0.2)


func _close_overlay() -> void:
	overlay.visible = false
	_build_level_cards()
	_refresh_profile()


func _add_close(text: String = "CLOSE") -> void:
	var b := _button(text, _close_overlay, 200, 20)
	b.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	b.add_theme_font_override("font", UiTheme.font_title())
	overlay_box.add_child(b)


func _choose_difficulty(idx: int) -> void:
	var lv := LevelDefs.get_level(idx)
	_open_overlay(lv["name"].to_upper())
	var bl := UiTheme.label(lv["blurb"], 18, UiTheme.PARCHMENT, UiTheme.font_italic())
	bl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	overlay_box.add_child(bl)
	var ri := RouteIcon.new(lv["path"], LevelDefs.theme(lv).get("icon", Color.WHITE))
	ri.custom_minimum_size = Vector2(500, 250)
	ri.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	overlay_box.add_child(ri)
	var roster: Array[String] = []
	for r in lv["roster"]:
		roster.append(EnemyDefs.get_def(r[0]).get("name", r[0]))
	var el := UiTheme.label("Enemies: %s.  Boss: %s." % [", ".join(roster), EnemyDefs.get_def(lv["boss"])["name"]], 15, Color(0.8, 0.75, 0.66))
	el.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	el.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	overlay_box.add_child(el)
	var row := HBoxContainer.new()
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_theme_constant_override("separation", 12)
	overlay_box.add_child(row)
	var got := Profile.medals(lv["id"])
	for d in LevelDefs.DIFFICULTY_ORDER:
		var dd: Dictionary = LevelDefs.DIFFICULTIES[d]
		var b := _button("%s%s\n%d lives, enemy HP x%.1f" % [dd["name"].to_upper(), "  (won)" if d in got else "", int(dd["lives"]) + Profile.start_lives_bonus(), float(dd["hp"])], _play.bind(idx, d, "campaign"), 220, 17)
		b.custom_minimum_size.y = 70
		b.add_theme_color_override("font_color", dd["color"])
		row.add_child(b)
	var er := HBoxContainer.new()
	er.alignment = BoxContainer.ALIGNMENT_CENTER
	overlay_box.add_child(er)
	if Profile.endless_unlocked():
		var eb := _button("ENDLESS MODE  (best: wave %d)" % Profile.endless_best(lv["id"]), _play.bind(idx, "normal", "endless"), 360, 17)
		eb.add_theme_color_override("font_color", Color(0.85, 0.55, 1.0))
		er.add_child(eb)
	else:
		er.add_child(UiTheme.label("Endless mode unlocks after beating Dragon's Reach.", 14, Color(0.6, 0.56, 0.5), UiTheme.font_italic()))
	_add_close("BACK")


func _play(idx: int, diff: String, mode: String) -> void:
	overlay.visible = false
	loading.visible = true
	# let the loading screen draw before the (heavy) battlefield build
	await get_tree().process_frame
	await get_tree().process_frame
	GameManager.start_level(idx, diff, mode)


func _show_armory() -> void:
	_open_overlay("ARMORY")
	var sub := UiTheme.label("Permanent upgrades bought with Crowns. You have %d Crowns." % Profile.crowns(), 17, UiTheme.PARCHMENT, UiTheme.font_italic())
	sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	sub.name = "Sub"
	overlay_box.add_child(sub)
	var grid := GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 12)
	grid.add_theme_constant_override("v_separation", 12)
	overlay_box.add_child(grid)
	for a in Profile.ARMORY:
		var p := _panel(Color(0.12, 0.1, 0.08, 0.95))
		p.custom_minimum_size = Vector2(360, 0)
		grid.add_child(p)
		var v := VBoxContainer.new()
		p.add_child(v)
		var rank := Profile.armory_rank(a["id"])
		var maxr: int = (a["costs"] as Array).size()
		var h := HBoxContainer.new()
		v.add_child(h)
		h.add_child(HudIcon.new(a["icon"], UiTheme.GOLD, 22))
		var nl := UiTheme.label(a["name"], 19, UiTheme.GOLD, UiTheme.font_title())
		nl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		h.add_child(nl)
		var pips := ""
		for k in maxr:
			pips += "# " if k < rank else "- "
		h.add_child(UiTheme.label(pips, 16, UiTheme.PARCHMENT, UiTheme.font_bold()))
		var dl := UiTheme.label(a["desc"], 15, UiTheme.PARCHMENT)
		dl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		v.add_child(dl)
		var cost := Profile.armory_next_cost(a["id"])
		var b := _button("MAXED" if cost < 0 else "BUY  (%d Crowns)" % cost, _buy.bind(a["id"]), 0, 15)
		b.disabled = cost < 0 or Profile.crowns() < cost
		v.add_child(b)
	_add_close()


func _buy(id: String) -> void:
	if Profile.buy_armory(id):
		Sfx.play("upgrade", -4.0)
		_show_armory()


func _show_achievements() -> void:
	_open_overlay("ACHIEVEMENTS")
	var n := 0
	for a in Profile.ACHIEVEMENTS:
		if Profile.has_achievement(a["id"]):
			n += 1
	var sub := UiTheme.label("%d / %d unlocked" % [n, Profile.ACHIEVEMENTS.size()], 17, UiTheme.PARCHMENT, UiTheme.font_italic())
	sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	overlay_box.add_child(sub)
	var grid := GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 10)
	grid.add_theme_constant_override("v_separation", 8)
	overlay_box.add_child(grid)
	for a in Profile.ACHIEVEMENTS:
		var got := Profile.has_achievement(a["id"])
		var p := _panel(Color(0.12, 0.1, 0.08, 0.95), UiTheme.GOLD if got else Color(0.3, 0.28, 0.25))
		p.custom_minimum_size = Vector2(360, 0)
		grid.add_child(p)
		var v := VBoxContainer.new()
		p.add_child(v)
		var h := HBoxContainer.new()
		v.add_child(h)
		h.add_child(HudIcon.new("star", UiTheme.GOLD if got else Color(0.3, 0.28, 0.25), 20))
		var nl := UiTheme.label(a["name"], 17, UiTheme.GOLD if got else Color(0.6, 0.57, 0.52), UiTheme.font_title())
		nl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		h.add_child(nl)
		h.add_child(UiTheme.label("+%d" % int(a["reward"]), 14, UiTheme.GOLD))
		var desc: String = a["desc"]
		if not got and a["stat"] != "":
			desc += "  (%d / %d)" % [min(Profile.stat(a["stat"]), int(a["goal"])), int(a["goal"])]
		var dl := UiTheme.label(desc, 14, UiTheme.PARCHMENT if got else Color(0.6, 0.57, 0.52))
		dl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		v.add_child(dl)
	var st := UiTheme.label("Lifetime: %d enemies slain, %d waves cleared, %d soldiers recruited, %d conversations, %d wins." % [
		Profile.stat("kills"), Profile.stat("waves"), Profile.stat("placed"), Profile.stat("talks"), Profile.stat("wins")], 15, Color(0.75, 0.7, 0.62))
	st.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	st.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	overlay_box.add_child(st)
	_add_close()


func _show_settings() -> void:
	_open_overlay("SETTINGS")
	overlay_box.add_child(SettingsPanel.build())
	overlay_box.add_child(UiTheme.label("DEMO & PROGRESS", 16, UiTheme.GOLD, UiTheme.font_title()))
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 10)
	overlay_box.add_child(row)
	row.add_child(_button("Unlock all levels & soldiers (demo)", _unlock_all, 0, 15))
	var reset := _button("Reset all progress", _reset, 0, 15)
	reset.add_theme_color_override("font_color", UiTheme.RED)
	row.add_child(reset)
	_add_close()


func _unlock_all() -> void:
	Profile.unlock_everything()
	Profile.toast.emit("Demo mode", "All levels and soldiers unlocked.", UiTheme.GREEN)
	_build_level_cards()


func _reset() -> void:
	Profile.reset_profile()
	Profile.toast.emit("Progress reset", "A fresh start, Commander.", UiTheme.RED)
	_close_overlay()


func _show_login() -> void:
	var reward := Profile.claim_login()
	if reward <= 0:
		return
	_open_overlay("WELCOME BACK")
	var l := UiTheme.label("Day %d login streak!\nThe royal treasury sends %d Crowns." % [Profile.login_streak(), reward], 22, UiTheme.PARCHMENT)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	overlay_box.add_child(l)
	var tip := UiTheme.label("Log in every day for bigger rewards (up to day 7). Daily quests and the daily challenge refresh at midnight.", 15, Color(0.75, 0.7, 0.62), UiTheme.font_italic())
	tip.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	tip.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	overlay_box.add_child(tip)
	Sfx.play("coin", -2.0)
	_add_close("COLLECT")


func _show_intro() -> void:
	Profile.data["seen_intro"] = true
	Profile.mark_dirty()
	_open_overlay("WELCOME, COMMANDER")
	var body := UiTheme.label(
		"Your towers are soldiers. Each one has a name, a personality and a voice.\n\n" +
		"Click a soldier to TALK, set who they target, give orders and upgrade them.\n" +
		"They warn each other about trolls, call knights for help, heal the fallen and rally against the dragon.\n\n" +
		"Beat each level to unlock a new kind of soldier. Earn Crowns for the Armory, finish daily quests,\n" +
		"and take on the Daily Challenge. Survive every road to unlock Endless mode.", 18, UiTheme.PARCHMENT)
	body.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	overlay_box.add_child(body)
	Profile.claim_login()
	_add_close("BEGIN")


func _quit() -> void:
	Profile.save_profile()
	get_tree().quit()
